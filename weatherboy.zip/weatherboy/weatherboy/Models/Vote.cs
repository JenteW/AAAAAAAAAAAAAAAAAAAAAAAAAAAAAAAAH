﻿namespace weatherboy.Models
{
    public class Vote
    {
        public int ID { get; set; }
        
        public string IP { get; set; }
        public int Song_ID { get; set; }
    
        public int Points { get; set; }
    }
}
