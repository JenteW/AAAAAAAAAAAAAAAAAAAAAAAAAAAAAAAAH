﻿namespace weatherboy.Models
{
    public class Song
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public int Artist_ID { get; set; }
        public string Spotify { get; set; }
        
    }
}
